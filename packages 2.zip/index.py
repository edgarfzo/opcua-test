import asyncio
import logging
from iodd import IODD
from information_node import InformationNode
from asyncua import Client, ua
import logging
import time
import json
import sys
import boto3


logger = logging.getLogger(__name__)
logging.basicConfig(stream=sys.stdout, level=logging.DEBUG)

EXTERNAL_OPCUA_ADDRESS = "192.168.1.250"
EXTERNAL_OPCUA_PORT = "4840"
TIMEOUT = 10


s3 = boto3.resource('s3')
async def main():
    i = 0
    print ("hi")
    url = 'opc.tcp://192.168.1.250:4840/'
    while True:
        # with open('ifm-000404-20200110-IODD1.1.xml', 'r') as f:
        #     data = f.read()
        bucketname = 'eafo-bucket-test' 
        filename = 'ifm-000404-20200110-IODD1.1.xml' 
        obj = s3.Object(bucketname, filename)
        data = obj.get()['Body'].read()
        msg = "First checkpoint" + str(data)[0:10]
        message_dict = {"message" : msg }

        async with Client(url=url) as client:

           
            info_node = InformationNode("test",144,16,1)
            
 

            msg = "second checkpoint" + str(info_node)
            message_dict = {"message" : msg }


            iodd_test = IODD(data,[''],[info_node],1)
            iodd_test._parse_information_nodes()


            msg = "third checkpoint"
            message_dict = {"message" : msg }
 

            for i in range (3): 
                print('')
            root = client.get_node(client.nodes.root)
            # bname = await root.read_browse_name()
            # print(bname)
            # bname2 = await root.read_display_name()
            # print(bname2)
            # bname3 = await root.read_description()
            # print(bname3)
            nodes_children = await root.get_children()
            #print(nodes_children)
            for i, node in enumerate(nodes_children):
                bname = await node.read_browse_name()
                dname = await node.read_display_name()
                dename = await node.read_description()
                if i == 0:
                    object_node = node
            
            object_children = await object_node.get_children()
            #print(object_children)
            for i, node in enumerate(object_children):
                if i == 1:
                    object_2_node = node
                    
            object_2_children = await object_2_node.get_children()
            
            # for i, node in enumerate(object_2_children):
            #     if i == 0:
            #         object_3_node = node
            # bname = object_3_node.nodeid
            vibration_node = client.get_node("ns=1;s=IOLM/Port 3/Attached Device/PDI Data Byte Array")
            value = await vibration_node.read_value()
            
            #print(type(value))
            result = info_node.byte_to_real_value(value)
   


            i = i + 1
            #print("result ", result)
            #print("- units: ['m/s', 'mm/s', 'in/s', 'm/s', 'mm/s', 'in/s']")
            for i in range (3): 
                print('')
            await asyncio.sleep(1)

       
        
       


asyncio.run(main())

def handler(event, context):
  return True